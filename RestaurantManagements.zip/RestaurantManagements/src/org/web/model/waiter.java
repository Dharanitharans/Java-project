package org.web.model;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class waiter {
	@Id
	private String waiterid;
	private String name;
	public String getWaiterid() {
		return waiterid;
	}
	public void setWaiterid(String waiterid) {
		this.waiterid = waiterid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

}
