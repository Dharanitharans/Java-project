package org.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CardDetails {
	@Id
	private long acc_No;
	private int exp_month;
	private int exp_year;
	private String card_Holder_Name;
	public long getAcc_No() {
		return acc_No;
	}
	public void setAcc_No(long acc_No) {
		this.acc_No = acc_No;
	}
	public int getExp_month() {
		return exp_month;
	}
	public void setExp_month(int exp_month) {
		this.exp_month = exp_month;
	}
	public int getExp_year() {
		return exp_year;
	}
	public void setExp_year(int exp_year) {
		this.exp_year = exp_year;
	}
	public String getCard_Holder_Name() {
		return card_Holder_Name;
	}
	public void setCard_Holder_Name(String card_Holder_Name) {
		this.card_Holder_Name = card_Holder_Name;
	}
}
