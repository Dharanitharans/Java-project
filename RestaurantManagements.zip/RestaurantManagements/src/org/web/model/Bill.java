package org.web.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Bill {
	@Id
	private Integer bill_Id;
	private Integer order_id;
	private double total_Amount;
	private Date date;
	public Integer getBill_Id() {
		return bill_Id;
	}
	public void setBill_Id(Integer bill_Id) {
		this.bill_Id = bill_Id;
	}
	public Integer getOrder_id() {
		return order_id;
	}
	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}
	public double getTotal_Amount() {
		return total_Amount;
	}
	public void setTotal_Amount(double total_Amount) {
		this.total_Amount = total_Amount;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	private double discount;

}
