package org.web.model; 
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class dinningtable {
	@Id
	public String getTable_status() {
		return table_status;
	}
	public void setTable_status(String table_status) {
		this.table_status = table_status;
	}
	public String getTablenumber() {
		return tablenumber;
	}
	public void setTablenumber(String tablenumber) {
		this.tablenumber = tablenumber;
	}
	private String table_status;
	private String tablenumber;


}
