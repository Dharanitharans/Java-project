package org.web.model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class orders {
	@Id
	private Integer order_id;
	private Integer itemId;
	private Integer tableNo;
	private double prize;
	public Integer getOrderId() {
		return getOrderId();
	}
	public void setOrderId(Integer orderId) {
		this.order_id = orderId;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public Integer getTableNo() {
		return tableNo;
	}
	public void setTableNo(Integer tableNo) {
		this.tableNo = tableNo;
	}
	public double getPrize() {
		return prize;
	}
	public void setPrize(Integer prize) {
		this.prize = prize;
	}
	}
